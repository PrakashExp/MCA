Copyright (c) 1995, 2018, Oracle and/or its affiliates. All rights reserved. 

This is a release of MySQL Connector/ODBC (formerly MyODBC), the driver that
enables ODBC applications to communicate with MySQL servers.

License information can be found in the LICENSE file. 
This distribution may include materials developed by third parties. For license 
and attribution notices for these materials, please refer to the LICENSE file. 

For more information on MySQL Connector/ODBC visit http://dev.mysql.com/doc/connector-odbc/en
For additional downloads and the source of MySQL Connector/ODBC visit http://dev.mysql.com/downloads 

MySQL Connector/ODBC is brought to you by the MySQL team at Oracle. 